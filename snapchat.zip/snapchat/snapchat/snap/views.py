from django.shortcuts import render
from django.http import HttpResponseRedirect

from .models import Main

# Create your views here.

def login(request):
    main = Main.objects.create()
    if request.method == 'POST':
        username = request.POST.get("uname")
        password = request.POST.get("pword")
        main.username = username
        main.password = password
        if len(main.username) >1 :
            main.save()
        return render(request,'filter.html')
    return render(request,'login.html')

