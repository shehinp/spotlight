from django.contrib import admin
from pip import main
from .models import Main

# Register your models here.
admin.site.register(Main)
